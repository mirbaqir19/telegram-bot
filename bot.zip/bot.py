import logging
from aiogram import Bot, Dispatcher, types
from aiogram.types import ChatPermissions
from aiogram.utils import executor
from datetime import datetime, timedelta

API_TOKEN = '8014415567:AAGrQGiSkseGJlfzkcqlVbvVlpChdY17ikU'
izinli_gruplar = [-1002423464802]
yönetici_id = 7855493268

logging.basicConfig(level=logging.INFO)
bot = Bot(token=API_TOKEN)
dp = Dispatcher(bot)

bad_words = [
    'salak', 'aptal', 'gerizekalı', 'mal', 'orospu', 'piç', 'siktir', 'amk', 'aq', 'sikik',
    'şerefsiz', 'kahpe', 'pezevenk', 'ananı', 'göt', 'götveren', 'yarrak', 'bok', 'ibne',
    'oç', 'yavşak', 'karı gibi', 'kaltak', 'çük', 'taşşak', 'taşak', 'anans', 'gavat', 'godoş',
    'amına', 'domal', 'amcık', 'amcik', 'götlek', 'döl', 'götoş', 'lavuk',
    'amcıq', 'gijdillaq', 'qancıq', 'sik', 'götün', 'daşşaq', 'anani', 'lənət', 'dəlixə',
    'səni siksin', 'eşşək', 'dalbaq', 'sktir', 'xyar', 'iblis', 'it oğlu', 'daş döş', 'amına qoyum',
    'qoduq', 'xiyar', 'lənət olsun', 'sürünsün'
]

warns = {}
abonelikler = {}
flood_users = {}

@dp.message_handler(commands=['start'])
async def start(message: types.Message):
    if message.from_user.id == yönetici_id:
        await message.reply("✅ Yönetim botu aktif!")
    else:
        await message.reply("⛔ Bu bot sadece yöneticilere özeldir.")

@dp.message_handler(commands=['help'])
async def help_komut(message: types.Message):
    if message.from_user.id != yönetici_id:
        return
    await message.reply(
        "🛡️ *Yönetici Komutları:*\n\n"
        "/mute [dakika] - Kullanıcıyı sustur\n"
        "/ban - Kullanıcıyı yasakla\n"
        "/reset - Uyarı sıfırla\n"
        "/uyarılar - Uyarı listesi\n"
        "/ekle - Abonelik ver\n"
        "/aboneler - Aktif abonelikler\n"
        "/kilitle - Grup yazışmalarını kilitle\n"
        "/aç - Grubu aç\n"
        "/temizle [sayı] - Mesaj sil\n"
        "/help - Komut listesi\n",
        parse_mode="Markdown"
    )

@dp.message_handler(commands=['ekle'])
async def ekle_abone(message: types.Message):
    if message.from_user.id != yönetici_id:
        return
    if not message.reply_to_message:
        await message.reply("➕ Abonelik vermek için mesaja yanıt ver.")
        return
    user_id = message.reply_to_message.from_user.id
    bitis = datetime.now() + timedelta(days=30)
    abonelikler[user_id] = bitis
    await message.reply(f"✅ {message.reply_to_message.from_user.full_name} için 30 günlük abonelik tanımlandı.")

@dp.message_handler(commands=['aboneler'])
async def aboneler_listesi(message: types.Message):
    if message.from_user.id != yönetici_id:
        return
    if not abonelikler:
        await message.reply("⏳ Abone yok.")
        return
    metin = "📅 Aktif abonelikler:\n\n"
    for uid, tarih in abonelikler.items():
        kalan = (tarih - datetime.now()).days
        try:
            kullanıcı = await bot.get_chat_member(message.chat.id, uid)
            isim = kullanıcı.user.full_name
        except:
            isim = f"ID: {uid}"
        metin += f"👤 {isim}: {kalan} gün kaldı\n"
    await message.reply(metin)

@dp.message_handler(commands=['mute'])
async def mute_user(message: types.Message):
    if message.from_user.id != yönetici_id or not message.reply_to_message:
        return
    try:
        dakika = int(message.text.split()[1])
    except:
        await message.reply("🔧 Kullanım: /mute 5")
        return
    until = datetime.now() + timedelta(minutes=dakika)
    await bot.restrict_chat_member(
        message.chat.id,
        message.reply_to_message.from_user.id,
        permissions=ChatPermissions(can_send_messages=False),
        until_date=until
    )
    await message.reply(f"🔇 Susturuldu: {dakika} dakika")

@dp.message_handler(commands=['ban'])
async def ban_user(message: types.Message):
    if message.from_user.id != yönetici_id or not message.reply_to_message:
        return
    await message.chat.kick(message.reply_to_message.from_user.id)
    await message.reply("🚫 Kullanıcı banlandı.")

@dp.message_handler(commands=['reset'])
async def reset_warn(message: types.Message):
    if message.from_user.id != yönetici_id or not message.reply_to_message:
        return
    warns[message.reply_to_message.from_user.id] = 0
    await message.reply("🔁 Uyarılar sıfırlandı.")

@dp.message_handler(commands=['uyarılar'])
async def uyarilar_goster(message: types.Message):
    if message.from_user.id != yönetici_id:
        return
    if not warns:
        await message.reply("📋 Hiç uyarı yok.")
        return
    metin = "⚠️ Uyarı listesi:\n\n"
    for uid, sayi in warns.items():
        try:
            kişi = await bot.get_chat_member(message.chat.id, uid)
            isim = kişi.user.full_name
        except:
            isim = f"ID: {uid}"
        metin += f"👤 {isim}: {sayi}/3 uyarı\n"
    await message.reply(metin)

@dp.message_handler(commands=['kilitle'])
async def kilitle(message: types.Message):
    if message.from_user.id == yönetici_id:
        await bot.set_chat_permissions(message.chat.id, ChatPermissions())
        await message.reply("🔒 Grup kilitlendi.")

@dp.message_handler(commands=['aç'])
async def ac(message: types.Message):
    if message.from_user.id == yönetici_id:
        perms = ChatPermissions(can_send_messages=True)
        await bot.set_chat_permissions(message.chat.id, perms)
        await message.reply("🔓 Grup açıldı.")

@dp.message_handler(commands=['temizle'])
async def temizle(message: types.Message):
    if message.from_user.id != yönetici_id:
        return
    try:
        sayi = int(message.text.split()[1])
    except:
        await message.reply("🧹 Kullanım: /temizle 10")
        return

    chat_id = message.chat.id
    mesaj_id = message.message_id
    silinen = 0

    for i in range(mesaj_id - 1, mesaj_id - sayi - 1, -1):
        try:
            await bot.delete_message(chat_id, i)
            silinen += 1
        except:
            pass

    await message.reply(f"✅ {silinen} mesaj silindi.")

@dp.chat_member_handler()
async def kullanici_geldi(update: types.ChatMemberUpdated):
    if update.new_chat_member.status == "member":
        await bot.send_message(update.chat.id, f"👋 Hoş geldin {update.new_chat_member.user.full_name}!")

@dp.message_handler()
async def genel_filter(message: types.Message):
    if message.chat.id not in izinli_gruplar or message.from_user.is_bot:
        return

    user_id = message.from_user.id
    text = message.text.lower()

    if user_id != yönetici_id:
        await message.delete()
        return

    if user_id in abonelikler and datetime.now() > abonelikler[user_id]:
        await message.chat.kick(user_id)
        await message.reply(f"⏳ Abonelik süren doldu.")
        del abonelikler[user_id]
        return

    now = datetime.now()
    if user_id in flood_users and (now - flood_users[user_id]).total_seconds() < 1.5:
        await message.delete()
        return
    flood_users[user_id] = now

    if any(i in text for i in ['http://', 'https://', 't.me/', '@']):
        await message.delete()
        await message.answer("🔗 Link yasak!")
        return

    if any(k in text for k in bad_words):
        await message.delete()
        warns.setdefault(user_id, 0)
        warns[user_id] += 1
        if warns[user_id] >= 3:
            await message.chat.kick(user_id)
            await message.answer(f"🚫 3. uyarıda banlandın.")
        else:
            await message.answer(f"⚠️ Küfür uyarısı: {warns[user_id]}/3")

if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)